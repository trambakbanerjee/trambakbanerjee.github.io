

library(MASS)
library(clusterGeneration)

source('ec_bootstrap_lib.R')

reps<-500
BB=500
pval.cutoff=0.05

#----------------------------------------------------------
experiment.1<-function(n.u,n.v,d,pval.cutoff,reps,BB){
  
  set.seed(1)
  Sigma.1 = genPositiveDefMat("eigen",dim=d)$Sigma
  set.seed(2)
  Sigma.2 = genPositiveDefMat("eigen",dim=d)$Sigma
  set.seed(3)
  Sigma.3 = genPositiveDefMat("eigen",dim=d)$Sigma
  
  test.truh<-matrix(0,reps,1)
  test.ec_bootstrap<-matrix(0,reps,4)
  test.ec<-matrix(0,reps,4)
  
  for(r in 1:reps){
    
    set.seed(r)
    p<-runif(n.u,0,1)
    set.seed(10*r)
    U<- (p<=0.3)*mvrnorm(n.u,rep(0,d),Sigma.1)+(p>0.3 & p<=0.6)*mvrnorm(n.u,rep(-3,d),Sigma.2)+(p>0.6)*mvrnorm(n.u,rep(3,d),Sigma.3)
    set.seed(20*r)
    q<-runif(n.v,0,1)
    set.seed(50*r)
    V<-(q<=0.1)*mvrnorm(n.v,rep(0,d),Sigma.1)+(q>0.1 & q<=0.2)*mvrnorm(n.v,rep(-3,d),Sigma.2)+(q>0.2)*mvrnorm(n.v,rep(3,d),Sigma.3)
    
    #-----------------gtests-------------------------------
    X <- rbind(U,V)
    dd <- dist(X)
    dd <- as.matrix(dd)
    counts = cbind(rep(c(1,0),c(n.u,n.v)),rep(c(0,1),c(n.u,n.v)))
    E = getGraph(counts, dd, 5, graph.type = "mstree")
    out.gtests<-g.tests(E,1:n.u,(n.u+1):(n.u+n.v),test.type="all")
    test1.ec<-out.gtests$original$pval.approx
    test1.gec<-out.gtests$generalized$pval.approx
    test1.wec<-out.gtests$weighted$pval.approx
    test1.mtec<-out.gtests$maxtype$pval.approx
    test.ec[r,] = c(test1.ec,test1.gec,test1.wec,test1.mtec)
   
    #----------------- TRUH ---------------------------
    out<-truh_consrv(V,U,BB,fc=1,a=pval.cutoff)
    test.truh[r]<-out$pval
    
    #----------------- EC Proposed ---------------------------
    out<-ec_bootstrap_revised(V,U,BB,out.gtests)
    test.ec_bootstrap[r,]= out$pval
    print(r)
    }
  rejrate_ec = colmeans(1*(test.ec<=pval.cutoff))
  rejrate_ec_bt = colmeans(1*(test.ec_bootstrap<=pval.cutoff))
  rejrate_truh = colmeans(1*(test.truh<=pval.cutoff))
  
  return(list("rejrate_ec"=rejrate_ec,
              "rejrate_ec_bt"=rejrate_ec_bt,
              "rejrate_truh"=rejrate_truh,
              "U"=U,
              "V"=V,
              "test.truh"=test.truh,
              "test.ec_bootstrap"=test.ec_bootstrap,
              "test.ec"=test.ec))
}
#----------------------------------------------------------
d<- 5 
out.d1.1<-experiment.1(500,50,d,pval.cutoff,reps,BB)
#***********************************************************************************************
d<- 15 
out.d2.1<-experiment.1(500,50,d,pval.cutoff,reps,BB)
#***********************************************************************************************
d<- 30 
out.d3.1<-experiment.1(500,50,d,pval.cutoff,reps,BB)


#***********************************************************************************************
d<- 5 
out.d1.2<-experiment.1(2000,200,d,pval.cutoff,reps,BB)
#***********************************************************************************************
d<- 15
out.d2.2<-experiment.1(2000,200,d,pval.cutoff,reps,BB)
#***********************************************************************************************
d<- 30
out.d3.2<-experiment.1(2000,200,d,pval.cutoff,reps,BB)


save.image('exp1s1.RData')


