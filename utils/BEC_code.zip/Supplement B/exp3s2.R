

library(MASS)
library(clusterGeneration)
library(CVTuningCov)
library(lcmix)

source('ec_bootstrap_lib.R')

reps<-500
BB=500
pval.cutoff=0.05

#----------------------------------------------------------
experiment.1<-function(n.u,n.v,d,pval.cutoff,reps,BB){
  
  Sigma.1 = AR1(d,0.7)
  Sigma.2 = AR1(d,-0.9)
  
  test.ec_bootstrap<-matrix(0,reps,4)
  test.ec<-matrix(0,reps,4)
  test.truh<-matrix(0,reps,1)
  
  set.seed(1)
  express.threshold.u = c(runif(0.8*d,0.5,0.6),rep(0,0.2*d))
  set.seed(1)
  express.threshold.v = c(runif(0.8*d,0.3,0.3),rep(0,0.2*d))
  
  thresh.u<- matrix(rep(express.threshold.u,n.u),n.u,byrow = T)
  thresh.v<- matrix(rep(express.threshold.v,n.v),n.v,byrow = T)
  
  for(r in 1:reps){
    
    set.seed(r)
    p1<-runif(n.u,0,1)
    set.seed(25*r)
    p2<-matrix(runif(n.u*d,0,1),n.u,d)
    set.seed(10*r)
    Y1<- (p1<=0.5)*rmvgamma(n.u,shape=runif(d,5,5),rate=rep(1,d),Sigma.1)+(p1>0.5)*rmvexp(n.u,rate=rep(1,d),Sigma.2)
    set.seed(11*r)
    U<- (p2>thresh.u)*Y1+(p2<=thresh.u)*rmvnorm(n.u,rep(0,d),0.0001*diag(d))
    
    set.seed(100*r)
    q1<-runif(n.v,0,1)
    set.seed(50*r)
    Y2<-(q1<=0.5)*rmvgamma(n.v,shape=runif(d,5,5),rate=rep(1.5,d),Sigma.1)+(q1>0.5)*rmvexp(n.v,rate=rep(1,d),Sigma.2)#rmvexp(n.v,rate=rep(0.5,d),Sigma.2)
    set.seed(30*r)
    q2<-matrix(runif(n.v*d,0,1),n.v,d)
    set.seed(17*r)
    V<-(q2>thresh.v)*Y2+(q2<=thresh.v)*rmvnorm(n.v,rep(0,d),0.0001*diag(d))
    
    #-----------------gtests-------------------------------
    X <- rbind(U,V)
    dd <- dist(X)
    dd <- as.matrix(dd)
    counts = cbind(rep(c(1,0),c(n.u,n.v)),rep(c(0,1),c(n.u,n.v)))
    E = getGraph(counts, dd, 5, graph.type = "mstree")
    out.gtests<-g.tests(E,1:n.u,(n.u+1):(n.u+n.v),test.type="all")
    test1.ec<-out.gtests$original$pval.approx
    test1.gec<-out.gtests$generalized$pval.approx
    test1.wec<-out.gtests$weighted$pval.approx
    test1.mtec<-out.gtests$maxtype$pval.approx
    test.ec[r,] = c(test1.ec,test1.gec,test1.wec,test1.mtec)
    
    #----------------- TRUH ---------------------------
    out<-truh_consrv(V,U,BB,fc=1,a=pval.cutoff)
    test.truh[r]<-out$pval
    
    #----------------- EC Proposed ---------------------------
    out<-ec_bootstrap_revised(V,U,BB,out.gtests)
    test.ec_bootstrap[r,]= out$pval
    print(r)
    }
  rejrate_ec = colmeans(1*(test.ec<=pval.cutoff))
  rejrate_ec_bt = colmeans(1*(test.ec_bootstrap<=pval.cutoff))
  rejrate_truh = colmeans(1*(test.truh<=pval.cutoff))
  
  return(list("rejrate_ec"=rejrate_ec,
              "rejrate_ec_bt"=rejrate_ec_bt,
              "rejrate_truh"=rejrate_truh,
              "U"=U,
              "V"=V,
              "test.truh"=test.truh,
              "test.ec_bootstrap"=test.ec_bootstrap,
              "test.ec"=test.ec))
}
#----------------------------------------------------------
d<- 5 
out.d1.1<-experiment.1(500,10,d,pval.cutoff,reps,BB)
#***********************************************************************************************
d<- 15 
out.d2.1<-experiment.1(500,10,d,pval.cutoff,reps,BB)
#***********************************************************************************************
d<- 30 
out.d3.1<-experiment.1(500,10,d,pval.cutoff,reps,BB)

save.image('exp3s2.RData')

#***********************************************************************************************
d<- 5 
out.d1.2<-experiment.1(2000,40,d,pval.cutoff,reps,BB)
save.image('exp3s2.RData')
#***********************************************************************************************
d<- 15
out.d2.2<-experiment.1(2000,40,d,pval.cutoff,reps,BB)
save.image('exp3s2.RData')
#***********************************************************************************************
d<- 30
out.d3.2<-experiment.1(2000,40,d,pval.cutoff,reps,BB)
save.image('exp3s2.RData')


