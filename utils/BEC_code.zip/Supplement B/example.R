
library(MASS)
library(clusterGeneration)

source('ec_bootstrap_lib.R')

# Set the parameters
n = 500
m = 50
d = 5
nB = 500
pval_cutoff = 0.05

# Data generation (setting borrowed from Experiment 1 Scenario 1)
set.seed(1)
Sigma.1 = genPositiveDefMat("eigen",dim=d)$Sigma
set.seed(2)
Sigma.2 = genPositiveDefMat("eigen",dim=d)$Sigma
set.seed(3)
Sigma.3 = genPositiveDefMat("eigen",dim=d)$Sigma

set.seed(4)
p<-runif(n,0,1)
set.seed(5)
X<- (p<=0.3)*mvrnorm(n,rep(0,d),Sigma.1)+(p>0.3 & p<=0.6)*mvrnorm(n,rep(-3,d),Sigma.2)+
  (p>0.6)*mvrnorm(n,rep(3,d),Sigma.3)

set.seed(6)
q<-runif(m,0,1)
set.seed(7)
Y<-(q<=0.1)*mvrnorm(m,rep(0,d),Sigma.1)+(q>0.1 & q<=0.2)*mvrnorm(m,rep(-3,d),Sigma.2)+
  (q>0.2)*mvrnorm(m,rep(3,d),Sigma.3)
    
#-----------------gtests-------------------------------
XX <- rbind(X,Y)
dd <- dist(XX)
dd <- as.matrix(dd)
counts = cbind(rep(c(1,0),c(n,m)),rep(c(0,1),c(n,m)))
E = getGraph(counts, dd, 5, graph.type = "mstree")
out.gtests<-g.tests(E,1:n,(n+1):(n+m),test.type="all")

#----------------- TRUH ---------------------------
out_truh<-truh_consrv(Y,X,nB,fc=1,a=pval.cutoff)

#----------------- Bootstrapped Edge Count tests ---------------------------
out_bootsrapped<-ec_bootstrap_revised(Y,X,nB,out.gtests)

## output the p-values
pval_ec = out.gtests$original$pval.approx
pval_gec = out.gtests$generalized$pval.approx
pval_wec = out.gtests$weighted$pval.approx

pval_truh = out_truh$pval
pval_bgec = out_bootsrapped$pval[2]
pval_bwec = out_bootsrapped$pval[3]