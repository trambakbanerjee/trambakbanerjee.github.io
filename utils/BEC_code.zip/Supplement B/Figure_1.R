
library(MASS)
library(ggpubr)
library(ggplot2)

source('ec_bootstrap_lib.R')

#----------------------------------------------------------
ec_bootstrap_motfig<-function(V,U,B,ec_teststat){
  
  hit_n_run = FALSE
  n.u<-dim(U)[1]
  n.v<-dim(V)[1]
  d.u<-dim(U)[2]
  d.v<-dim(V)[2]
  
  n.u.b<-n.u-n.v
  n.v.b<-n.v
  
  #------------ cutoff computation --------------------
  cl <- makeCluster(6)
  registerDoParallel(cl)
  
  X<-U
  set.seed(1)
  k.hat<-4
  clust.X <-clara(X,k=k.hat,metric="euclidean",samples=50,sampsize=500)$clustering
  mu<-table(clust.X)
  a.param<-rep(0.1,k.hat)
  if(min(mu)<n.v.b){
    hit_n_run = TRUE
    amat = as.matrix(diag(k.hat))
    bmat = c(pmin(mu/n.v.b,1))
  }
  
  result<-foreach(b = 1:B,.packages=c("Rfast","gTests","igraph","MCMCpack","polyapost"))%dopar%{
    
    list.u.b<-list()
    list.v.b<-list()
    if(k.hat>1){
      if(hit_n_run){
        set.seed(b)
        dr<-hitrun(a.param,a1=amat,b1 = bmat)$batch
      }
      else{
        set.seed(b)
        dr<-rdirichlet(1,a.param)
      }
      s.v<-as.integer(dr*n.v)
      s.v[k.hat]<-n.v-sum(s.v[1:(k.hat-1)])
      for(k in 1:k.hat){
        clust.idx<-which(clust.X==k)
        
        set.seed(k*b)
        idx1.v<-sample(clust.idx,s.v[k],replace=(s.v[k]>mu[k]))
        idx1.u<-clust.idx[!(clust.idx %in% idx1.v)]
        list.v.b[[k]]<- X[idx1.v,]
        list.u.b[[k]]<-X[idx1.u,]
      }
    } else{
      clust.idx<-which(clust.X==1)
      s.v = n.v
      set.seed(b)
      idx1.v<-sample(clust.idx,s.v,replace=(s.v>mu[1]))
      idx1.u<-clust.idx[!(clust.idx %in% idx1.v)]
      list.v.b[[1]]<- X[idx1.v,]
      list.u.b[[1]]<-X[idx1.u,]
      
    }
    if(d.u>1){
      VV.b<- do.call(rbind,list.v.b)
      UU.b<- do.call(rbind,list.u.b)
    } else {
      VV.b<-as.matrix(unlist(list.v.b))
      UU.b<-as.matrix(unlist(list.u.b))
    }
    #-----------------gtests-------------------------------
    XX.b<-rbind(UU.b,VV.b)
    dd.b <- dist(XX.b)
    dd.b <- as.matrix(dd.b)
    counts.b = cbind(rep(c(1,0),c(n.u.b,n.v.b)),rep(c(0,1),c(n.u.b,n.v.b)))
    E.b = getGraph(counts.b, dd.b, 5, graph.type = "mstree")
    outgtests.b<-g.tests(E.b,1:n.u.b,(n.u.b+1):(n.u.b+n.v.b),test.type="all")
    dist.null<-c(outgtests.b$original$test.statistic,outgtests.b$generalized$test.statistic,
                 outgtests.b$weighted$test.statistic,outgtests.b$maxtype$test.statistic)
    rm(list=c('dd.b','XX.b'))
    return(dist.null)
  }
  dist.null<-do.call(rbind,result)
  #*******************************************************************
  pval<-c(sum(1*(dist.null[,1]<ec_teststat$original$test.statistic)),
          sum(1*(dist.null[,2]>ec_teststat$generalized$test.statistic)),
          sum(1*(dist.null[,3]>ec_teststat$weighted$test.statistic)),
          sum(1*(dist.null[,4]>ec_teststat$maxtype$test.statistic)))/B
  stopCluster(cl)
  registerDoSEQ()
  return(list("pval"=pval,"null.dist"=dist.null))
}

#----------------------------------------------------------
experiment.d2.1<-function(n.u,n.v,nB,pval.cutoff,reps){
  
  d.u<-2
  d.v<-2
  Sigma.u = diag(d.u)
  Sigma.v = diag(d.v)
  
  test.truh<-matrix(0,reps,1)
  test.ec_bootstrap<-matrix(0,reps,4)
  test.ec<-matrix(0,reps,4)
  
  for(r in 1:reps){
    
    set.seed(r)
    p<-runif(n.u,0,1)
    set.seed(10*r)
    U<- (p<=0.25)*mvrnorm(n.u,c(10,10),Sigma.u)+(p>0.25 & p<=0.5)*mvrnorm(n.u,c(20,10),Sigma.u)+
      (p>0.5 & p<=0.75)*mvrnorm(n.u,c(20,20),Sigma.u)+(p>0.75)*mvrnorm(n.u,c(10,20),Sigma.u)
    set.seed(20*r)
    q<-runif(n.v,0,1)
    set.seed(50*r)
    V<-(q<=0.25)*mvrnorm(n.v,c(10,10),Sigma.v)+(q>0.25 & q<=0.5)*mvrnorm(n.v,c(20,10),Sigma.v)+
      (q>0.5 & q<=0.75)*mvrnorm(n.v,c(20,20),Sigma.v)+(q>0.75)*mvrnorm(n.v,c(10,20),Sigma.v)
    
    #-----------------gtests-------------------------------
    X <- rbind(U,V)
    d <- dist(X)
    d <- as.matrix(d)
    counts = cbind(rep(c(1,0),c(n.u,n.v)),rep(c(0,1),c(n.u,n.v)))
    E = getGraph(counts, d, 9, graph.type = "mstree")
    out.gtests<-g.tests(E,1:n.u,(n.u+1):(n.u+n.v),test.type="all")
    test1.ec<-out.gtests$original$pval.approx
    test1.gec<-out.gtests$generalized$pval.approx
    test1.wec<-out.gtests$weighted$pval.approx
    test1.mtec<-out.gtests$maxtype$pval.approx
    test.ec[r,] = c(test1.ec,test1.gec,test1.wec,test1.mtec)
    
    #----------------- TRUH ---------------------------
    out<-truh_consrv(V,U,nB,fc=1,a=pval.cutoff)
    test.truh[r]<-out$pval
    
    #----------------- EC Proposed ---------------------------
    out<-ec_bootstrap_motfig(V,U,nB,out.gtests)
    test.ec_bootstrap[r,]= out$pval
    print(r)
  }
  
  rejrate_ec = colmeans(1*(test.ec<=pval.cutoff))
  rejrate_ec_bt = colmeans(1*(test.ec_bootstrap<=pval.cutoff))
  rejrate_truh = colmeans(1*(test.truh<=pval.cutoff))
  
  
  
  return(list("rejrate_ec"=rejrate_ec,"rejrate_ec_bt"=rejrate_ec_bt,
              "rejrate_truh"=rejrate_truh,"U"=U,
              "V"=V,"test.truh"=test.truh,"test.ec_bootstrap"=test.ec_bootstrap,
              "test.ec"=test.ec))
}
#----------------------------------------------------------
experiment.d2.2<-function(n.u,n.v,nB,pval.cutoff,reps){
  
  d.u<-2
  d.v<-2
  Sigma.u = diag(d.u)
  Sigma.v = diag(d.v)
  
  test.truh<-matrix(0,reps,1)
  test.ec_bootstrap<-matrix(0,reps,4)
  test.ec<-matrix(0,reps,4)
  
  for(r in 1:reps){
    
    set.seed(r)
    p<-runif(n.u,0,1)
    set.seed(10*r)
    U<- (p<=0.25)*mvrnorm(n.u,c(10,10),Sigma.u)+(p>0.25 & p<=0.5)*mvrnorm(n.u,c(20,10),Sigma.u)+
      (p>0.5 & p<=0.75)*mvrnorm(n.u,c(20,20),Sigma.u)+(p>0.75)*mvrnorm(n.u,c(10,20),Sigma.u)
    set.seed(20*r)
    q<-runif(n.v,0,1)
    set.seed(50*r)
    V<-(q<=0.8)*mvrnorm(n.v,c(20,10),Sigma.v)+(q>0.8 & q<=0.9)*mvrnorm(n.v,c(10,10),Sigma.v)+(q>0.9)*mvrnorm(n.v,c(20,20),Sigma.v)
    
    #-----------------gtests-------------------------------
    X <- rbind(U,V)
    d <- dist(X)
    d <- as.matrix(d)
    counts = cbind(rep(c(1,0),c(n.u,n.v)),rep(c(0,1),c(n.u,n.v)))
    E = getGraph(counts, d, 9, graph.type = "mstree")
    out.gtests<-g.tests(E,1:n.u,(n.u+1):(n.u+n.v),test.type="all")
    test1.ec<-out.gtests$original$pval.approx
    test1.gec<-out.gtests$generalized$pval.approx
    test1.wec<-out.gtests$weighted$pval.approx
    test1.mtec<-out.gtests$maxtype$pval.approx
    test.ec[r,] = c(test1.ec,test1.gec,test1.wec,test1.mtec)
    
    #----------------- TRUH ---------------------------
    out<-truh_consrv(V,U,nB,fc=1,a=pval.cutoff)
    test.truh[r]<-out$pval
    
    #----------------- EC Proposed ---------------------------
    out<-ec_bootstrap_motfig(V,U,nB,out.gtests)
    test.ec_bootstrap[r,]= out$pval
    print(r)
  }
  
  rejrate_ec = colmeans(1*(test.ec<=pval.cutoff))
  rejrate_ec_bt = colmeans(1*(test.ec_bootstrap<=pval.cutoff))
  rejrate_truh = colmeans(1*(test.truh<=pval.cutoff))
  
  return(list("rejrate_ec"=rejrate_ec,"rejrate_ec_bt"=rejrate_ec_bt,
              "rejrate_truh"=rejrate_truh,"U"=U,
              "V"=V,"test.truh"=test.truh,"test.ec_bootstrap"=test.ec_bootstrap,
              "test.ec"=test.ec))
}
#----------------------------------------------------------
experiment.d2.3<-function(n.u,n.v,nB,pval.cutoff,reps){
  
  d.u<-2
  d.v<-2
  Sigma.u = diag(d.u)
  Sigma.v = diag(d.v)
  
  test.truh<-matrix(0,reps,1)
  test.ec_bootstrap<-matrix(0,reps,4)
  test.ec<-matrix(0,reps,4)
  
  for(r in 1:reps){
    
    set.seed(r)
    p<-runif(n.u,0,1)
    set.seed(10*r)
    U<- (p<=0.25)*mvrnorm(n.u,c(10,10),Sigma.u)+(p>0.25 & p<=0.5)*mvrnorm(n.u,c(20,10),Sigma.u)+
      (p>0.5 & p<=0.75)*mvrnorm(n.u,c(20,20),Sigma.u)+(p>0.75)*mvrnorm(n.u,c(10,20),Sigma.u)
    set.seed(20*r)
    q<-runif(n.v,0,1)
    set.seed(50*r)
    V<-mvrnorm(n.v,c(25,5),Sigma.v)
    #-----------------gtests-------------------------------
    X <- rbind(U,V)
    d <- dist(X)
    d <- as.matrix(d)
    counts = cbind(rep(c(1,0),c(n.u,n.v)),rep(c(0,1),c(n.u,n.v)))
    E = getGraph(counts, d, 9, graph.type = "mstree")
    out.gtests<-g.tests(E,1:n.u,(n.u+1):(n.u+n.v),test.type="all")
    test1.ec<-out.gtests$original$pval.approx
    test1.gec<-out.gtests$generalized$pval.approx
    test1.wec<-out.gtests$weighted$pval.approx
    test1.mtec<-out.gtests$maxtype$pval.approx
    test.ec[r,] = c(test1.ec,test1.gec,test1.wec,test1.mtec)
    
    #----------------- TRUH ---------------------------
    out<-truh_consrv(V,U,nB,fc=1,a=pval.cutoff)
    test.truh[r]<-out$pval
    
    #----------------- EC Proposed ---------------------------
    out<-ec_bootstrap_motfig(V,U,nB,out.gtests)
    test.ec_bootstrap[r,]= out$pval
    print(r)
  }
  
  rejrate_ec = colmeans(1*(test.ec<=pval.cutoff))
  rejrate_ec_bt = colmeans(1*(test.ec_bootstrap<=pval.cutoff))
  rejrate_truh = colmeans(1*(test.truh<=pval.cutoff))
  
  return(list("rejrate_ec"=rejrate_ec,"rejrate_ec_bt"=rejrate_ec_bt,
              "rejrate_truh"=rejrate_truh,"U"=U,
              "V"=V,"test.truh"=test.truh,"test.ec_bootstrap"=test.ec_bootstrap,
              "test.ec"=test.ec))
}
#----------------------------------------------------------

#***********************************************************************************************
n.u<-2000
n.v<-200
reps<-500
nB=500
pval.cutoff=0.05

out.d2.1<-experiment.d2.1(n.u,n.v,nB,pval.cutoff,reps)
out.d2.2<-experiment.d2.2(n.u,n.v,nB,pval.cutoff,reps)
out.d2.3<-experiment.d2.3(n.u,n.v,nB,pval.cutoff,reps)

save.image('Figure_1.RData')

plotdata.1<-as.data.frame(rbind(out.d2.1$U,out.d2.1$V))
plotdata.1$case<- c(rep('Pre-event',n.u),rep('Post-event',n.v))
plotdata.1$case = factor(plotdata.1$case,levels=c("Pre-event","Post-event"),
                         labels = c("Pre-event","Post-event"))
plotdata.1$codes<- c(rep('#00FF00',n.u),rep('#FF0000',n.v))
g1<-ggplot(plotdata.1, aes(x = V1, y = V2,color=case,shape=case))+geom_point(size=2)+
  xlab('Spending on sector A ($)')+ylab('Spending on sector B ($)')+
  theme_bw()+
  theme(axis.text.x = element_text(size=15),
        axis.text.y = element_text(size=15),
        axis.title.x = element_text(size=15),
        axis.title.y = element_text(size=15),
        legend.text = element_text(size=15),
        legend.title = element_blank())

#--------------------------------------------------------------------


plotdata.2<-as.data.frame(rbind(out.d2.2$U,out.d2.2$V))
plotdata.2$case<- c(rep('Pre-event',n.u),rep('Post-event',n.v))
plotdata.2$case = factor(plotdata.1$case,levels=c("Pre-event","Post-event"),
                         labels = c("Pre-event","Post-event"))
plotdata.2$codes<- c(rep('#7bb5cc',n.u),rep('#FF0000',n.v))

g2<-ggplot(plotdata.2, aes(x = V1, y = V2,color=case,shape=case))+geom_point(size=2)+
  xlab('Spending on sector A ($)')+ylab('Spending on sector B ($)')+
  theme_bw()+
  theme(axis.text.x = element_text(size=15),
        axis.text.y = element_text(size=15),
        axis.title.x = element_text(size=15),
        axis.title.y = element_text(size=15),
        legend.text = element_text(size=15),
        legend.title = element_blank())

#--------------------------------------------------------------------


plotdata.3<-as.data.frame(rbind(out.d2.3$U,out.d2.3$V))
plotdata.3$case<- c(rep('Pre-event',n.u),rep('Post-event',n.v))
plotdata.3$case = factor(plotdata.1$case,levels=c("Pre-event","Post-event"),
                         labels = c("Pre-event","Post-event"))
plotdata.3$codes<- c(rep('#7bb5cc',n.u),rep('#FF0000',n.v))

g3<-ggplot(plotdata.3, aes(x = V1, y = V2,color=case,shape=case))+geom_point(size=2)+
  xlab('Spending on sector A ($)')+ylab('Spending on sector B ($)')+
  theme_bw()+
  theme(axis.text.x = element_text(size=15),
        axis.text.y = element_text(size=15),
        axis.title.x = element_text(size=15),
        axis.title.y = element_text(size=15),
        legend.text = element_text(size=15),
        legend.title = element_blank())

ggarrange(g1, g2, g3, ncol=3, nrow=1, common.legend = TRUE, legend="top")
