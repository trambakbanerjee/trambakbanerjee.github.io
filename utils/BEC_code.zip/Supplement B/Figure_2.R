
library(MASS)
library(ggplot2)
library(ggpubr)
library(scatterplot3d)

source('ec_bootstrap_lib.R')
  

#----------------------------------------------------------
experiment.d2.1<-function(n.u,n.v,nB,pval.cutoff,reps){
  
  d.u<-3
  d.v<-3
  Sigma.u = diag(d.u)
  Sigma.v = diag(d.v)
  
  test.truh<-matrix(0,reps,1)
  test.ec_bootstrap<-matrix(0,reps,4)
  test.ec<-matrix(0,reps,4)
  
  for(r in 1:reps){
    
    set.seed(r)
    p<-runif(n.u,0,1)
    set.seed(10*r)
    U<- (p<=0.3)*mvrnorm(n.u,c(0,0,0),Sigma.u)+(p>0.3 & p<=0.6)*mvrnorm(n.u,c(0,-4,-4),Sigma.u)+(p>0.6)*mvrnorm(n.u,c(4,-2,-3),Sigma.u)
    set.seed(20*r)
    q<-runif(n.v,0,1)
    set.seed(50*r)
    V<-(q<=0.3)*mvrnorm(n.v,c(0,0,0),Sigma.v)+(q>0.3 & q<=0.6)*mvrnorm(n.v,c(0,-4,-4),Sigma.v)+(q>0.6)*mvrnorm(n.v,c(4,-2,-3),Sigma.v)
    
    #-----------------gtests-------------------------------
    X <- rbind(U,V)
    d <- dist(X)
    d <- as.matrix(d)
    counts = cbind(rep(c(1,0),c(n.u,n.v)),rep(c(0,1),c(n.u,n.v)))
    E = getGraph(counts, d, 5, graph.type = "mstree")
    out.gtests<-g.tests(E,1:n.u,(n.u+1):(n.u+n.v),test.type="all")
    test1.ec<-out.gtests$original$pval.approx
    test1.gec<-out.gtests$generalized$pval.approx
    test1.wec<-out.gtests$weighted$pval.approx
    test1.mtec<-out.gtests$maxtype$pval.approx
    test.ec[r,] = c(test1.ec,test1.gec,test1.wec,test1.mtec)
    
    #----------------- TRUH ---------------------------
    out<-truh_consrv(V,U,nB,fc=1,a=pval.cutoff)
    test.truh[r]<-out$pval
    
    #----------------- EC Proposed ---------------------------
    out<-ec_bootstrap_revised(V,U,nB,out.gtests)
    test.ec_bootstrap[r,]= out$pval
    print(r)
  }
  
  rejrate_ec = colmeans(1*(test.ec<=pval.cutoff))
  rejrate_ec_bt = colmeans(1*(test.ec_bootstrap<=pval.cutoff))
  rejrate_truh = colmeans(1*(test.truh<=pval.cutoff))
  
 

  return(list("rejrate_ec"=rejrate_ec,"rejrate_ec_bt"=rejrate_ec_bt,
              "rejrate_truh"=rejrate_truh,"U"=U,
              "V"=V,"test.truh"=test.truh,"test.ec_bootstrap"=test.ec_bootstrap,
              "test.ec"=test.ec))
}
#----------------------------------------------------------
experiment.d2.2<-function(n.u,n.v,nB,pval.cutoff,reps){
  
  d.u<-3
  d.v<-3
  Sigma.u = diag(d.u)
  Sigma.v = diag(d.v)
  
  test.truh<-matrix(0,reps,1)
  test.ec_bootstrap<-matrix(0,reps,4)
  test.ec<-matrix(0,reps,4)
  
  for(r in 1:reps){
    
    set.seed(r)
    p<-runif(n.u,0,1)
    set.seed(10*r)
    U<- (p<=0.3)*mvrnorm(n.u,c(0,0,0),Sigma.u)+(p>0.3 & p<=0.6)*mvrnorm(n.u,c(0,-4,-4),Sigma.u)+(p>0.6)*mvrnorm(n.u,c(4,-2,-3),Sigma.u)
    set.seed(20*r)
    q<-runif(n.v,0,1)
    set.seed(50*r)
    V<-(q<=0.8)*mvrnorm(n.v,c(0,0,0),Sigma.v)+(q>0.8 & q<=0.9)*mvrnorm(n.v,c(0,-4,-4),Sigma.u)+(q>0.9)*mvrnorm(n.v,c(4,-2,-3),Sigma.u)
    #-----------------gtests-------------------------------
    X <- rbind(U,V)
    d <- dist(X)
    d <- as.matrix(d)
    counts = cbind(rep(c(1,0),c(n.u,n.v)),rep(c(0,1),c(n.u,n.v)))
    E = getGraph(counts, d, 5, graph.type = "mstree")
    out.gtests<-g.tests(E,1:n.u,(n.u+1):(n.u+n.v),test.type="all")
    test1.ec<-out.gtests$original$pval.approx
    test1.gec<-out.gtests$generalized$pval.approx
    test1.wec<-out.gtests$weighted$pval.approx
    test1.mtec<-out.gtests$maxtype$pval.approx
    test.ec[r,] = c(test1.ec,test1.gec,test1.wec,test1.mtec)
    
    #----------------- TRUH ---------------------------
    out<-truh_consrv(V,U,nB,fc=1,a=pval.cutoff)
    test.truh[r]<-out$pval
    
    #----------------- EC Proposed ---------------------------
    out<-ec_bootstrap_revised(V,U,nB,out.gtests)
    test.ec_bootstrap[r,]= out$pval
    print(r)
  }
  
  rejrate_ec = colmeans(1*(test.ec<=pval.cutoff))
  rejrate_ec_bt = colmeans(1*(test.ec_bootstrap<=pval.cutoff))
  rejrate_truh = colmeans(1*(test.truh<=pval.cutoff))
  
  return(list("rejrate_ec"=rejrate_ec,"rejrate_ec_bt"=rejrate_ec_bt,
              "rejrate_truh"=rejrate_truh,"U"=U,
              "V"=V,"test.truh"=test.truh,"test.ec_bootstrap"=test.ec_bootstrap,
              "test.ec"=test.ec))
}
#----------------------------------------------------------
experiment.d2.3<-function(n.u,n.v,nB,pval.cutoff,reps){
  
  d.u<-3
  d.v<-3
  Sigma.u = diag(d.u)
  Sigma.v = 0.1*diag(d.v)
  
  test.truh<-matrix(0,reps,1)
  test.ec_bootstrap<-matrix(0,reps,4)
  test.ec<-matrix(0,reps,4)
  
  for(r in 1:reps){
    
    set.seed(r)
    p<-runif(n.u,0,1)
    set.seed(10*r)
    U<- (p<=0.3)*mvrnorm(n.u,c(0,0,0),Sigma.u)+(p>0.3 & p<=0.6)*mvrnorm(n.u,c(0,-4,-4),Sigma.u)+(p>0.6)*mvrnorm(n.u,c(4,-2,-3),Sigma.u)
    set.seed(20*r)
    q<-runif(n.v,0,1)
    set.seed(50*r)
    V<-(q<=0.8)*mvrnorm(n.v,c(0,0,0),Sigma.v)+(q>0.8 & q<=0.9)*mvrnorm(n.v,c(0,-4,-4),Sigma.u)+(q>0.9)*mvrnorm(n.v,c(4,-2,-3),Sigma.u)
    #-----------------gtests-------------------------------
    X <- rbind(U,V)
    d <- dist(X)
    d <- as.matrix(d)
    counts = cbind(rep(c(1,0),c(n.u,n.v)),rep(c(0,1),c(n.u,n.v)))
    E = getGraph(counts, d, 5, graph.type = "mstree")
    out.gtests<-g.tests(E,1:n.u,(n.u+1):(n.u+n.v),test.type="all")
    test1.ec<-out.gtests$original$pval.approx
    test1.gec<-out.gtests$generalized$pval.approx
    test1.wec<-out.gtests$weighted$pval.approx
    test1.mtec<-out.gtests$maxtype$pval.approx
    test.ec[r,] = c(test1.ec,test1.gec,test1.wec,test1.mtec)
    
    #----------------- TRUH ---------------------------
    out<-truh_consrv(V,U,nB,fc=1,a=pval.cutoff)
    test.truh[r]<-out$pval
    
    #----------------- EC Proposed ---------------------------
    out<-ec_bootstrap_revised(V,U,nB,out.gtests)
    test.ec_bootstrap[r,]= out$pval
    print(r)
  }
  
  rejrate_ec = colmeans(1*(test.ec<=pval.cutoff))
  rejrate_ec_bt = colmeans(1*(test.ec_bootstrap<=pval.cutoff))
  rejrate_truh = colmeans(1*(test.truh<=pval.cutoff))
  
  return(list("rejrate_ec"=rejrate_ec,"rejrate_ec_bt"=rejrate_ec_bt,
              "rejrate_truh"=rejrate_truh,"U"=U,
              "V"=V,"test.truh"=test.truh,"test.ec_bootstrap"=test.ec_bootstrap,
              "test.ec"=test.ec))
}
#***********************************************************************************************
n.u<-2000
n.v<-200
reps<-500
nB=500
pval.cutoff=0.05

out.d2.1<-experiment.d2.1(n.u,n.v,nB,pval.cutoff,reps)
out.d2.2<-experiment.d2.2(n.u,n.v,nB,pval.cutoff,reps)
out.d2.3<-experiment.d2.3(n.u,n.v,nB,pval.cutoff,reps)
save.image('Figure_2.RData')

plotdata.1<-as.data.frame(rbind(out.d2.1$V,out.d2.1$U))
plotdata.1$case<- c(rep('Current players',n.v),rep('Normal players',n.u))
plotdata.1$case = factor(plotdata.1$case,levels=c("Current players","Normal players"),
                         labels = c("Current players","Normal players"))
plotdata.1$codes<- c(rep('#FF0000',n.v),rep('#00FF00',n.u))
plotdata.1$shapes<- c(rep(17,n.v),rep(16,n.u))

plotdata.2<-as.data.frame(rbind(out.d2.2$V,out.d2.2$U))
plotdata.2$case<- c(rep('Current players',n.v),rep('Normal players',n.u))
plotdata.2$case = factor(plotdata.2$case,levels=c("Current players","Normal players"),
                         labels = c("Current players","Normal players"))
plotdata.2$codes<- c(rep('#FF0000',n.v),rep('#00FF00',n.u))
plotdata.2$shapes<- c(rep(17,n.v),rep(16,n.u))

plotdata.3<-as.data.frame(rbind(out.d2.3$V,out.d2.3$U))
plotdata.3$case<- c(rep('Current players',n.v),rep('Normal players',n.u))
plotdata.3$case = factor(plotdata.3$case,levels=c("Current players","Normal players"),
                         labels = c("Current players","Normal players"))
plotdata.3$codes<- c(rep('#FF0000',n.v),rep('#00FF00',n.u))
plotdata.3$shapes<- c(rep(17,n.v),rep(16,n.u))

nf<-layout(matrix(c(1, 2,3), ncol=3))

scatterplot3d(plotdata.1[,1:3], pch=plotdata.1$shapes,color=plotdata.1$codes, col.axis="blue",
              main="",  xlab = expression(X[1]),
              ylab = expression(X[2]),
              zlab = expression(X[3]),
              box=FALSE,cex.symbols=1,cex.axis = 2)
scatterplot3d(plotdata.2[,1:3], pch=plotdata.2$shapes,color=plotdata.2$codes, col.axis="blue",
              main="",  xlab = expression(X[1]),
              ylab = expression(X[2]),
              zlab = expression(X[3]),
              box=FALSE,cex.symbols=1,cex.axis = 2)
legend("top", legend = levels(plotdata.1$case),
       col =  c('#FF0000','#00FF00'), pch = c(17,16), inset = -0.1, xpd = TRUE, horiz = TRUE,
       cex=2,pt.cex = 2,bty = 'n')
scatterplot3d(plotdata.3[,1:3], pch=plotdata.3$shapes,color=plotdata.3$codes, col.axis="blue",
              main="",  xlab = expression(X[1]),
              ylab = expression(X[2]),
              zlab = expression(X[3]),
              box=FALSE,cex.symbols=1,cex.axis = 2)


