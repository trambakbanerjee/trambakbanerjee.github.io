library(Rfast)
library(fpc)
library(cluster)
library(MCMCpack)
library(gTests)
library(igraph)
library(polyapost)
library(foreach)
library(doParallel)
library(iterators)


ec_bootstrap_revised<-function(V,U,B,ec_teststat){
  
  # U: the n x d matrix of the bigger baseline sample 
  # V: the m x d matrix of the smaller sample
  # B: number of bootstrap replications
  # ec_teststat: edge count test statistics (output from using gtests)
  
  hit_n_run = FALSE
  n.u<-dim(U)[1]
  n.v<-dim(V)[1]
  d.u<-dim(U)[2]
  d.v<-dim(V)[2]
  
  n.u.b<-n.u-n.v
  n.v.b<-n.v
  
  #------------ cutoff computation --------------------
  #***********************************************************************
  cl <- makeCluster(6)
  registerDoParallel(cl)
  
  X<-U
  set.seed(1)
  k.hat<-prediction.strength(X, Gmin=2, Gmax=10,cutoff = 0.8)$optimalk
  clust.X <-clara(X,k=k.hat,metric="euclidean",samples=50,sampsize=500)$clustering
  mu<-table(clust.X)
  a.param<-rep(0.1,k.hat)
  if(min(mu)<n.v.b){
    hit_n_run = TRUE
    amat = as.matrix(diag(k.hat))
    bmat = c(pmin(mu/n.v.b,1))
  }
  
  result<-foreach(b = 1:B,.packages=c("Rfast","gTests","igraph","MCMCpack","polyapost"))%dopar%{
    
    list.u.b<-list()
    list.v.b<-list()
    if(k.hat>1){
      if(hit_n_run){
        set.seed(b)
        dr<-hitrun(a.param,a1=amat,b1 = bmat)$batch
      }
      else{
        set.seed(b)
        dr<-rdirichlet(1,a.param)
      }
      s.v<-as.integer(dr*n.v)
      s.v[k.hat]<-n.v-sum(s.v[1:(k.hat-1)])
      for(k in 1:k.hat){
        clust.idx<-which(clust.X==k)
        
        set.seed(k*b)
        idx1.v<-sample(clust.idx,s.v[k],replace=(s.v[k]>mu[k]))
        idx1.u<-clust.idx[!(clust.idx %in% idx1.v)]
        list.v.b[[k]]<- X[idx1.v,]
        list.u.b[[k]]<-X[idx1.u,]
      }
    } else{
      clust.idx<-which(clust.X==1)
      s.v = n.v
      set.seed(b)
      idx1.v<-sample(clust.idx,s.v,replace=(s.v>mu[1]))
      idx1.u<-clust.idx[!(clust.idx %in% idx1.v)]
      list.v.b[[1]]<- X[idx1.v,]
      list.u.b[[1]]<-X[idx1.u,]
      
    }
    if(d.u>1){
      VV.b<- do.call(rbind,list.v.b)
      UU.b<- do.call(rbind,list.u.b)
    } else {
      VV.b<-as.matrix(unlist(list.v.b))
      UU.b<-as.matrix(unlist(list.u.b))
    }
    #-----------------gtests-------------------------------
    XX.b<-rbind(UU.b,VV.b)
    dd.b <- dist(XX.b)
    dd.b <- as.matrix(dd.b)
    counts.b = cbind(rep(c(1,0),c(n.u.b,n.v.b)),rep(c(0,1),c(n.u.b,n.v.b)))
    E.b = getGraph(counts.b, dd.b, 5, graph.type = "mstree")
    outgtests.b<-g.tests(E.b,1:n.u.b,(n.u.b+1):(n.u.b+n.v.b),test.type="all")
    dist.null<-c(outgtests.b$original$test.statistic,outgtests.b$generalized$test.statistic,
                 outgtests.b$weighted$test.statistic,outgtests.b$maxtype$test.statistic)
    rm(list=c('dd.b','XX.b'))
    return(dist.null)
  }
  dist.null<-do.call(rbind,result)
  #*******************************************************************
  pval<-c(sum(1*(dist.null[,1]<ec_teststat$original$test.statistic)),
          sum(1*(dist.null[,2]>ec_teststat$generalized$test.statistic)),
          sum(1*(dist.null[,3]>ec_teststat$weighted$test.statistic)),
          sum(1*(dist.null[,4]>ec_teststat$maxtype$test.statistic)))/B
  stopCluster(cl)
  registerDoSEQ()
  return(list("pval"=pval,"null.dist"=dist.null))
}

# Functions borrowed from Banerjee et. al (AoAS 2020)
#-------------------------------------------------------

truh_consrv<-function(V,U,B,fc=1,a=0.05){
  
  n.u<-dim(U)[1]
  n.v<-dim(V)[1]
  d.u<-dim(U)[2]
  d.v<-dim(V)[2]
  
  out.nearest<- matrix(0,n.v,3)
  for(i in 1:dim(V)[1]){
    out.nearest[i,]<-nearest(V[i,],U,n.u,d.u)
  }
  fac<-(n.v^{1/d.u})*(d.u>1)+1*(d.u==1)
  teststat.truh<-fac*mean(out.nearest[,1]-1*out.nearest[,2])
  
  #------------ cutoff computation --------------------
  #****************** METHOD 3 *******************************************
  cl <- makeCluster(10)
  registerDoParallel(cl)
  
  X<-U
  set.seed(1)
  k.hat<-prediction.strength(X, Gmin=2, Gmax=10,cutoff = 0.8)$optimalk
  clust.X <-clara(X,k=k.hat,metric="euclidean",samples=50,sampsize=500)$clustering
  mu<-table(clust.X)
  temp1<-diag(k.hat)
  pval<-matrix(0,k.hat,1)
  dist.null<-matrix(0,B,k.hat)
  
  for(k in 1:k.hat){
    
    s.v<-ceiling(temp1[k,k]*n.v)
    clust.idx<-which(clust.X==k)
    result<-foreach(b = 1:B,.packages="Rfast",.export="nearest")%dopar%{#for(b in 1:B){
      set.seed(k*b)
      idx1.v<-sample(clust.idx,s.v,replace=(s.v>mu[k]))
      VV.b<- X[idx1.v,]
      UU.b<-X[-idx1.v,]
      out<- matrix(0,dim(VV.b)[1],2)
      for(i in 1:dim(VV.b)[1]){
        out[i,]<-nearest(VV.b[i,],UU.b,dim(UU.b)[1],d.u)[1:2]
      }
      fac<-(n.v^{1/d.u})*(d.u>1)+1*(d.u==1)
      dist.null<-fac*mean(fc*out[,1]-1*out[,2])
      return(dist.null)
    }
    dist.null[,k]<-do.call(rbind,result)
    # c1<-quantile(dist.null[,k],a/2)
    # c2<-quantile(dist.null[,k],1-a/2)
    pval[k]<-sum(1*(dist.null[,k]>teststat.truh))/B
  }
  stopCluster(cl)
  registerDoSEQ()
  
  return(list("teststat"=teststat.truh,"pval"=max(pval),"pval_all"=pval,
              "dist.null_all"=dist.null))
}

nearest<-function(y,U,n=100,d=10){
  b1=matrix(y,ncol=d,nrow=n,byrow=T)
  temp=rowsums(abs(b1-U))
  ind1=which.min(temp);
  y.u=U[ind1,];
  d1=temp[ind1];
  
  b2=matrix(y.u,ncol=d,nrow=n-1,byrow=T)
  U1=as.matrix(U[-c(ind1),]);
  temp=rowsums(abs(b2-U1))
  ind2=which.min(temp);
  u.u=U1[ind2,];
  d2=temp[ind2];
  return(c(d1,d2,d1-d2))
}







