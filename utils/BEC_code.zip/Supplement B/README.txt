
This folder holds R files for doing the following:
--------------------------------------------------

1. Replicate the simulation results in Figures 1,2 and Section 4 of the manuscript, and Section C of Supplement A.

2. An example code to run the Bootstrapped edge count tests on your own simulation setting.

What packages do I need?
---------------------------

You will need the following R packages to be installed:

Rfast, fpc, cluster, MCMCpack, gTests, igraph, polyapost, foreach, doParallel, iterators, MASS,
clusterGeneration, CVTuningCov, lcmix, ggpubr, ggplot2, scatterplot3d

What hardware setting do I need?
------------------------------------

You will need atleast 6 cores in your system since the bootstrap replications are distributed across multiple cores for 
computational efficiency.


How to replicate the simulation results in the paper?
------------------------------------------------------

R files with names expAsB.R refer to simulation experiment 'A' and scenario 'B'. So, for example, if you
want to replicate the results of Experiment 3 Scenario I then run 'exp3s1.R'. Similarly, for replicating the
results in Section C of Supplement A, run 'exp4sB.R' where B=1,2,3 for the three scenarios. 
Make sure that 'ec_boostrap_lib.R' is in your working directory and all packages listed above are already installed. 
R codes 'Figure_1.R' and 'Figure_2.R' will replicate tables 7 and 8 in Supplement A and Figures 1 and 2 in the manuscript.

How can I run Bootstrapped edge count tests on my own simulation example?
-------------------------------------------------------------------------

Look at example.R which already includes an example setting to run the proposed tests. 


