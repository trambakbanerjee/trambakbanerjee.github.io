
library(Rfast)
library(ggplot2)


setwd('<set you working directory')
load("<path to>/out.RData")

#1. Get sphagetti plots of linear regression residuals with duration of play as the response

#---------------------------------------------------------------------

y<-out$y.train
evec<-out$e.train
x<-cbind(rep(1,dim(out$x.train)[1]),out$x.train)
z<-cbind(rep(1,dim(out$z.train)[1]),out$z.train)
gg<-out$g.train
guild_mem<-out$gm.train

m<-16
n<-dim(x)[1]/(m-1)
pc<-dim(z)[2]
pfpc<-dim(x)[2]
pg<-dim(gg)[2]
K<-dim(guild_mem)[2]

# Create G matrix first n(m-1) by pg
G<- matrix(0,n*(m-1),pg)
for(i in 1:n){
  
  s<-1+(i-1)*(m-1)
  e<-(m-1)*i
  temp1<-matrix(rep(c(guild_mem[s:e,]),pg),ncol=pg,byrow = F)
  temp2<-temp1*gg
  idx<-which(temp2!=0,arr.ind = T)#(temp2!=0)
  G[s:e,]<-matrix(gg[unique(idx[,1]),],ncol=pg,byrow = F)
}

#---- Prepare data for Linear Regression ------------------------
xx<-cbind(x,G)
DF <- data.frame(xx)
DF$y<-matrix(0,n*(m-1),1)
DF$y[y>0]<-log(y[y>0])
id <- rep(1:n, each = m-1)
id.t <- rep(1:(m-1), n)
id.g<- matrix(0,n*(m-1))
for(i in 1:n){
  s<-1+(i-1)*(m-1)
  e<-(m-1)*i
  id.g[s:e]<- sapply(s:e, function(j)which.max(guild_mem[j,]))
}
DF$id <- id
DF$id.t<- id.t
DF$id.g<- id.g
DF<- DF[y>0,]

m2<-lm(y ~ X2+X3+X4++X5+X6+X7+X8+X9+X10+X11+X12+X13+X14+X15+X16+X17+X18+X19+X20+X21+X22+X23,
         data = DF)

plotdata1<- data.frame(cbind(m2$residuals,DF$id,DF$id.t,DF$id.g))
names(plotdata1)<- c('residuals','id','Days','guild')
player_id = unique(plotdata1$id)
player_guild = unique(plotdata1$guild)

plotdata1$id<- as.factor(plotdata1$id)
set.seed(2)
ss = sample(player_id,200,replace = F)
mean_residual_i<- sapply(1:length(ss),
                       function(i)mean(plotdata1$residuals[plotdata1$id==ss[i]]))
q_residual_i<- sapply(1:length(ss),function(i)quantile(plotdata1$residuals[plotdata1$id==ss[i]],
                  seq(0.05,1,by=0.05)))
plotdata3<- data.frame(cbind(mean_residual_i,as.factor(ss)))
names(plotdata3)<- c('mean_residual','id')
plotdata4<- as.matrix(t(q_residual_i))

coul <- heat.colors(20)
library(lattice)
g1<-levelplot(plotdata4,
              col.regions=coul,
              xlab="Players",ylab="Percentiles",main="",
              aspect = "fill")

mean_residual_jk<- aggregate(plotdata1$residuals,list(plotdata1$Days,plotdata1$guild),FUN=mean)
mean_residual_jk<- rbind(mean_residual_jk[1:735,],c(1,50,0),mean_residual_jk[736:749,])
cc<- matrix(mean_residual_jk[,3],nrow=50,byrow = T)
x.scale <- list(at=seq(1,50,1))

coul <- heat.colors(20)
library(lattice)
g3<-levelplot(cc,
              col.regions=coul,
              scales = list(x = x.scale),
              ylab="Days",xlab="Guilds",
              aspect="fill")
library(ggpubr)
ggarrange(g2,g3,ncol=2)
